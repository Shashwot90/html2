$(document).ready(function(){
    $(".four").owlCarousel({
        items: 4,
        nav: true,
    });
  });
  $(document).ready(function(){
    $(".three").owlCarousel({
        items: 3,
        nav: true,
    });
  });
  $(document).ready(function(){
    $(".two").owlCarousel({
        items: 2,
        
    });
  });